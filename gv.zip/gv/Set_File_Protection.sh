#!/bin/sh
#
# This sh script will automatically set the
# file protection for all files contained in
# the Gv-6.0 directory. Only a user that has 'su' privilege
# or the 'owner' can properly execute this
# script. To execute properly, this script
# must remain in the Gv-6.0 root directory.
#
if [ ! -f Set_File_Protection.sh ]; then
   echo ERROR - Please \'cd\' to the Gv-6.0 directory to run this script.
   exit 0
fi
if [ ! "${AMPAC_KEYDIR:-set}" = "set" ]; then
   if [ -f "$AMPAC_KEYDIR/ampac10.key" ]; then
      chmod 644 "$AMPAC_KEYDIR/ampac10.key"
   fi
fi
if [ ! "${HOME:-set}" = "set" ]; then
   if [ -f "$HOME/.semichem/ampac10.key" ]; then
      chmod 644 "$HOME/.semichem/ampac10.key"
   fi
fi
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644  {} \;
find . -name 'lib*' -exec chmod 755 {} \;
find . -name '*.exe' -exec chmod 755 {} \;
find . -name '*.awk' -exec chmod 755 {} \;
find . -name '*.csh' -exec chmod 755 {} \;
find . -name '*.sh' -exec chmod 755 {} \;
find . -type f -name 'gview' -exec chmod 755 {} \;
find . -type f -name 'scjobmangui' -exec chmod 755 {} \;
find . -type f -name 'gmmx.exe' -exec chmod 755 {} \;
find . -type f -name 'gmmx' -exec chmod 755 {} \;
find . -type f -name 'lib*.so*' -exec chmod 755 {} \;
find . -type f -name 'lib*.dylib' -exec chmod 755 {} \;
find . -type f -name 'lib*.a' -exec chmod 755 {} \;
find ./exec -type f -name '*' -exec chmod 755 {} \;
chmod 744 Set_File_Protection.sh
echo 'File Protection Adjusted.'
