#!/bin/sh
#
# SCJobManGui 1.1.15 launch script.
#
#    Copyright (c) 1992-2016 Semichem, Inc.
#    All Rights Reserved
#


# Find the real path of the directory containing this script
currentDir=`pwd`
hmnFile=$0
cd "`dirname "$hmnFile"`"
hmnFile=`basename "$hmnFile"`
while [ -L "$hmnFile" ]
do
  hmnFile=`readlink "$hmnFile"`
  cd "`dirname "$hmnFile"`"
  hmnFile=`basename "$hmnFile"`
done
scriptDir=`pwd -P`
cd ..
scriptParentDir=`pwd -P`
cd "$currentDir"

unset SCJOBMANGUI_DIR

# If SCJOBMANGUI_DIR is not already set to a valid directory, set SCJOBMANGUI_DIR to the directory containing this script
# or its parent directory depending on the relative location of scjobmangui.exe or scjobmangui.app.
# Shouldn't need to export SCJOBMANGUI_DIR, so don't do it ...
if [ "${SCJOBMANGUI_DIR:-set}" = "set" ] || [ ! -d "$SCJOBMANGUI_DIR" ]; then
  if [ "${SCJOBMANGUI_DIR:-set}" != "set" ]; then
#    echo SCJOBMANGUI_DIR was set as an invalid directory.
    unset SCJOBMANGUI_DIR
  fi
  if [ -f "${scriptDir}/scjobmangui.exe" ] || [ -f "${scriptDir}/scjobmangui.app/Contents/MacOS/scjobmangui" ]; then
    SCJOBMANGUI_DIR=$scriptDir
  elif [ -f "${scriptParentDir}/scjobmangui.exe" ] || [ -f "${scriptParentDir}/scjobmangui.app/Contents/MacOS/scjobmangui" ]; then
    SCJOBMANGUI_DIR=$scriptParentDir
  else
    echo scjobmangui executable not found!
    exit 1
  fi
#  echo Setting SCJOBMANGUI_DIR to "$SCJOBMANGUI_DIR"
fi


# Look for some script arguments
for arg; do
  case "$arg" in
    -mesagl|-soft)
        USE_MESAGL=1
        ;;
  esac
done


# Set various shared library search path environment variables
if [ "$USE_MESAGL" ]
then
  SCJOBMANGUI_LIB_PATH="${SCJOBMANGUI_DIR}/lib:${SCJOBMANGUI_DIR}/lib/MesaGL"
else
  SCJOBMANGUI_LIB_PATH="${SCJOBMANGUI_DIR}/lib"
fi
export LD_LIBRARY_PATH="${SCJOBMANGUI_LIB_PATH}:${LD_LIBRARY_PATH}"
#export LIBPATH="${SCJOBMANGUI_LIB_PATH}:${LIBPATH}"
#export LIBRARY_PATH="${SCJOBMANGUI_LIB_PATH}:${LIBRARY_PATH}"
#export SHLIB_PATH="${SCJOBMANGUI_LIB_PATH}:${SHLIB_PATH}"
#export LD_LIBRARYN32_PATH="${SCJOBMANGUI_LIB_PATH}:${LD_LIBRARYN32_PATH}"
#export DYLD_LIBRARY_PATH="${SCJOBMANGUI_LIB_PATH}:${DYLD_LIBRARY_PATH}"


# Set some other environment variables useful for SCJobManGUI
export ALLOWINDIRECT=1
export QT_PLUGIN_PATH="${SCJOBMANGUI_DIR}/plugins"


# Launch SCJobManGUI
if [ -f "${SCJOBMANGUI_DIR}/scjobmangui.exe" ]; then
  exec "${SCJOBMANGUI_DIR}/scjobmangui.exe" "$@"
elif [ -f "${SCJOBMANGUI_DIR}/scjobmangui.app/Contents/MacOS/scjobmangui" ]; then
  exec "${SCJOBMANGUI_DIR}/scjobmangui.app/Contents/MacOS/scjobmangui" "$@"
else
  echo scjobmangui executable not found!
fi
