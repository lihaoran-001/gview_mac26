              Installation of GaussView 6.0 for UNIX Systems

Prelimary step for all systems:
0.  Select a group that will have access to GaussView. This should not 
    be an administrative group. You may want to create a new group for
    this purpose. Contact your system administrator if you need help with
    this process.  If you are using or will be installing G16 on the
    same machine, the same group should be used for both.

Scenario 1: Gaussian 16 and GaussView on the SAME computer:
1.  Install Gaussian 16 from its DVD first, following the installation
    instructions provided with it (and also included on the Gaussian 16 DVD).

2.  Mount the GaussView DVD or find the icon for where it was mounted
    automatically.

3.  Change to the C shell, and set the g16root and mntpnt environment 
    variables:

    $ /bin/csh
    % setenv mntpnt "/mnt/dvd  "       # Set to wherever dvd is mounted.
    % setenv g16root "<dir>"           # Set to location of g16 directory.
    % cd $g16root

    The correct directory to specify in the third command is the location 
    of the g16 subdirectory, not the path to that directory. Thus, if the 
    path to the Gaussian 16 directory is /apps/chem/g16, then set g16root 
    to /apps/chem.

    If you already have a gv directory because a previous version of GV
    is installed, remove this directory:

    rm -fr gv

4.  Read the DVD and set the group ownership for the new gv directory:

    % bzip2 -d -c $mntpnt/tar/*.tbz | tar xvf -
    % chgrp -R <grp> gv                # <grp> is group selected in step 0.

5.  You are now ready to run. The g16 initialization script has set up 
    an alias named gv which points to the correct directory.

GV UNIX Install--Page 2 of 2

Scenario 2: Gaussian 16 and GaussView on DIFFERENT computers:
1.  If Gaussian 16 will not be used on the computer where GaussView is to
    be installed, you must install the Gaussian Utilities.  Install these
    from the Gaussian Utilities DVD first, following the installation
    instructions provided with it (and also included on the Gaussian DVD).

2.  Mount the DVD.

3.  Change to the C shell, and set the g16root and mntpnt environment 
    variables:

    $ /bin/csh
    % setenv mntpnt "/mnt/dvd"         # Set to wherever dvd is mounted.
    % setenv g16root "<dir>"           # Set to location of utilities directory.
    % cd $g16root

    The correct directory to specify in the third command is the location 
    of the g16 subdirectory, not the path to that directory. Thus, if the 
    path to the Gaussian Utilities directory is /apps/chem/g16, then set
    g16root to /apps/chem.

4.  Read the DVD:

    % bzip2 -d -c $mntpnt/tar/*.tbz | tar xvf -
    % chgrp -R <grp> gv                # <grp> is the group from step 0.

5.  You are now ready to run. The utilities initialization script has set up 
    an alias named gv which points to the correct directory.
