#!/bin/sh
#
# GaussView 6.0 launch script.
#
#    Copyright (c) 1992-2016 Semichem, Inc.
#    All Rights Reserved
#


# Find the real path of the directory containing this script
currentDir=`pwd`
hmnFile=$0
cd "`dirname "$hmnFile"`"
hmnFile=`basename "$hmnFile"`
while [ -L "$hmnFile" ]
do
  hmnFile=`readlink "$hmnFile"`
  cd "`dirname "$hmnFile"`"
  hmnFile=`basename "$hmnFile"`
done
scriptDir=`pwd -P`
cd ..
scriptParentDir=`pwd -P`
cd "$currentDir"

unset GV_DIR

# If GV_DIR is not already set to a valid directory, set GV_DIR to the directory containing this script
# or its parent directory depending on the relative location of gview.exe or gview.app.
# Shouldn't need to export GV_DIR, so don't do it ...
if [ "${GV_DIR:-set}" = "set" ] || [ ! -d "$GV_DIR" ]; then
  if [ "${GV_DIR:-set}" != "set" ]; then
#    echo GV_DIR was set as an invalid directory.
    unset GV_DIR
  fi
  if [ -f "${scriptDir}/gview.exe" ] || [ -f "${scriptDir}/gview.app/Contents/MacOS/gview" ]; then
    GV_DIR=$scriptDir
  elif [ -f "${scriptParentDir}/gview.exe" ] || [ -f "${scriptParentDir}/gview.app/Contents/MacOS/gview" ]; then
    GV_DIR=$scriptParentDir
  else
    echo gview executable not found!
    exit 1
  fi
#  echo Setting GV_DIR to "$GV_DIR"
fi


# Look for some script arguments
for arg; do
  case "$arg" in
    -mesagl|-soft)
        USE_MESAGL=1
        ;;
  esac
done


# Set various shared library search path environment variables
if [ "$USE_MESAGL" ]
then
  GV_LIB_PATH="${GV_DIR}/lib:${GV_DIR}/lib/MesaGL"
else
  GV_LIB_PATH="${GV_DIR}/lib"
fi
export LD_LIBRARY_PATH="${GV_LIB_PATH}:${LD_LIBRARY_PATH}"
#export LIBPATH="${GV_LIB_PATH}:${LIBPATH}"
#export LIBRARY_PATH="${GV_LIB_PATH}:${LIBRARY_PATH}"
#export SHLIB_PATH="${GV_LIB_PATH}:${SHLIB_PATH}"
#export LD_LIBRARYN32_PATH="${GV_LIB_PATH}:${LD_LIBRARYN32_PATH}"
#export DYLD_LIBRARY_PATH="${GV_LIB_PATH}:${DYLD_LIBRARY_PATH}"


# Set some other environment variables useful for GV
export ALLOWINDIRECT=1
export QT_PLUGIN_PATH="${GV_DIR}/plugins"


# Launch GV
if [ -f "${GV_DIR}/gview.exe" ]; then
  exec "${GV_DIR}/gview.exe" "$@"
elif [ -f "${GV_DIR}/gview.app/Contents/MacOS/gview" ]; then
  exec "${GV_DIR}/gview.app/Contents/MacOS/gview" "$@"
else
  echo gview executable not found!
fi
